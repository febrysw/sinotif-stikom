import { Component, OnInit } from "@angular/core";
import { IonicSlides } from "@ionic/angular";

@Component({
  selector: "app-home",
  templateUrl: "./home.page.html",
  styleUrls: ["./home.page.scss"],
})
export class HomePage implements OnInit {
  swiperModules = [IonicSlides];
  runningText: string = "Selamat datang di SINOTIF";
  slides: any[] = [];
  recent: any[] = [];

  constructor() {}

  async ngOnInit() {
    console.log("ngOnInit HomePage");
    this.recent = [
      {
        slug: "https://www.stikombanyuwangi.ac.id/index.php/Home/berita_lengkap/293",
        images:
          "https://www.stikombanyuwangi.ac.id/img/images-berita/1702891519WEBB.jpg",
        datahtml:
          "Rabu, 27 Desember 2023<br><br>PENDAFTARAN MAHASISWA BARU STIKOM PGRI BANYUWANGI TAHUN 2024",
        colorhtml: "light",
        fonthtml: "11px",
      },
      {
        slug: "https://www.stikombanyuwangi.ac.id/index.php/Home/berita_lengkap/293",
        images:
          "https://www.stikombanyuwangi.ac.id/img/images-berita/1702891519WEBB.jpg",
        datahtml:
          "Rabu, 27 Desember 2023<br><br>PENDAFTARAN MAHASISWA BARU STIKOM PGRI BANYUWANGI TAHUN 2024",
        colorhtml: "light",
        fonthtml: "11px",
      },
      {
        slug: "https://www.stikombanyuwangi.ac.id/index.php/Home/berita_lengkap/293",
        images:
          "https://www.stikombanyuwangi.ac.id/img/images-berita/1702891519WEBB.jpg",
        datahtml:
          "Rabu, 27 Desember 2023<br><br>PENDAFTARAN MAHASISWA BARU STIKOM PGRI BANYUWANGI TAHUN 2024",
        colorhtml: "light",
        fonthtml: "11px",
      },
      {
        slug: "https://www.stikombanyuwangi.ac.id/index.php/Home/berita_lengkap/293",
        images:
          "https://www.stikombanyuwangi.ac.id/img/images-berita/1702891519WEBB.jpg",
        datahtml:
          "Rabu, 27 Desember 2023<br><br>PENDAFTARAN MAHASISWA BARU STIKOM PGRI BANYUWANGI TAHUN 2024",
        colorhtml: "light",
        fonthtml: "11px",
      },
    ];
    this.slides = [
      {
        title: "Computer",
        description: "Description about computer...",
        url: "https://www.stikombanyuwangi.ac.id/img/download/logo%20stikom%20baru.png",
      },
      {
        title: "Building",
        description: "Building description...",
        url: "assets/sinotif/pmb.jpg",
      },
      {
        title: "Glass over a computer",
        description: "Description of a glass over a computer",
        url: "assets/sinotif/banner.jpg",
      },
    ];
  }

  goToNotif() {
    console.log("goToNotif");
  }

  goToMenu() {
    console.log("goToMenu");
  }
}
