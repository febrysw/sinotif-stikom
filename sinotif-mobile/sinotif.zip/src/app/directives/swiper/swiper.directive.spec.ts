import { SwiperDirective } from './swiper.directive';

describe('SwiperDirective', () => {
  it('should create an instance', () => {
    const directive = new SwiperDirective();
    expect(directive).toBeTruthy();
  });
});
